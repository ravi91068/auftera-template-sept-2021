<?php

$servername = "database-1.c2kbgonwhnk5.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$dbname = "template_name_def";

$temp_def_conn = mysqli_connect($servername, $username, $password,$dbname);


function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}


function crt_query_sel($arr){


$str="";
	foreach($arr as $val){

$str.=" tag like '%".$val."%' or";

	}

return substr($str,0,-2);

}



$tag_name=json_decode($_POST['tag_name']);

$sel_query="select * from temp_def where ".crt_query_sel($tag_name);

print_r(json_encode(select_query($temp_def_conn,$sel_query)));


?>
