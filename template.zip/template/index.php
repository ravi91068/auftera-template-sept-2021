
<?php
session_start();

$_SESSION['id']="497889959";

$id=$_SESSION['id'];

?>






<html><head>


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">
<style type="text/css">


.sd-con-ico.dsc-inln-flx {
    width: 8%;
    height: 100%;
}

.main-con-of-crm.dsc-inln-flx {
    width: 92%;
    height: 100%;
    float: right;
    overflow: scroll;
    background: #fafafa;
}

    .dsc-inln-flx {
    display: inline-block;
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

    .icon-con-of-sd {
    height: 90vh;
    width: 100%;
}

.icon-main-con {
    height: auto;
    width: 100%;
    position: relative;
    top: 50%;
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    }

    .con-ico {
    padding: 20px;
    text-align: center;
}

img.con-of-ico-img {
    height: 30px;
    }




.con-of-main-splt {
    width: 20%;
    height: 100vh;
    display: inline-block;

}
.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

   
h2.head-od-dt-shw {
    margin: 0px;
    }


button.btn-of-drk-back {
    height: 6vh;
    width: 100%;
    background: #125ef6;
    border: 0px;
    border-radius: 5px;
    color: white;
}

.con-of-dt-sel-ele {
    height: 80vh;
    width: 100%;
    overflow: scroll;
    }

    .container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 15px;
}
a.com-for-lnk {
    text-decoration: none;
    color: black;
    }

    h2.head-od-dt-shw {
    margin: 0px;
    font-family: lato;
    font-size: 15px;
    font-weight: bolder;
}
.con-of-main-splt {
    width: 20%;
    height: 100vh;
    background: #e5eafc30;
    }


    .eml-add-main-con {
    width: 29%;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    font-size: 16px;
    
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }
    input.srch-ip-fld {
    width: 100%;
    height: 3vh;
    border: none;
    font-family: 'Lato';
    font-weight: 500;
    color: #c7ccd7;
}
.con-of-full-email-dt {
    width: 100%;
    height: 90vh;
    }

    .img-eml-ico-con {
    font-family: 'Lato';
    padding: 15px;
    border-radius: 50%;
    background: pink;
    margin-right: 10px;
    color: #ca1938;
}
.sub-ln-of-email-txt {
    width: 240px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: 'Lato';
    color: #908c8c;
    font-size: 13px;
}
input.srch-ip-fld:focus{
    outline: none;
    border: none;
}

    .fnt-ico-sel {
    width: 20px;
    text-align: center;
}

.con-of-cht-usr {
    width: 50%;
    display: inline-block;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    border-left: 1px solid #f2f2f2;
    }





.con-ico:hover{
    cursor: pointer;
}

.head-of-dash{
    background: #4a154b;
    text-align: right;
    border-bottom-left-radius: 50px;
}


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;
}

button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
    }

    .dropdown-header {
    padding: .5rem 1rem;
    color: #f6f9fc;
    font-size: .625rem;
    text-transform: uppercase;
    font-weight: 700;
}
.dropdown-header {
    display: block;
    padding: .5rem 1rem;
    margin-bottom: 0;
    font-size: 0.875rem;
    color: #8898aa;
    white-space: nowrap;
    }
    .dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
}

.dropdown-item {
    border-radius: 10px;
    }

h6, .h6 {
    font-size: 0.625rem !important;
}


.head-of-inn-con {
    padding: 24px;
}
.all-auta-con {
    padding: 0px 24px;
    }
    span.nm-auta-con {
    font-size: 16px;
    font-weight: 500;
    font-family: 'lato';
    color: #00000080;
}

.crt-new-auta-con {
    width: 200px;
    background: rgb(4, 135, 175);
    padding: 24px 16px;
    border-radius: 10px;
    height: 250px;
    margin-right: 30px;
    margin-top: 20px;
}

    .new-crt-head {
    line-height: 28px;
    font-weight: 700;
    color: white;
    font-family: 'Lato';
}
.con-of-crt-new-img {
    text-align: center;
    width: min-content;
    margin-top: 60px;
    padding: 10px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 50%;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
    }

    .crt-new-auta-con:hover{
cursor: pointer;
    }

    .auta-dis-on-dash {
    width: 240px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: auto;
    margin-left: auto;
    height: 300px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    transition: .3s;
    margin-top: 20px;
}

.auta-dis-on-dash:hover{
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
cursor: pointer;

}
.main-con-name {
    flex: auto;
    min-height: 166px;
    display: inline-grid;
    width: 100%;
    height: 252px;
    border-radius: 5px;
    }
    
    span.bdg-tp-btn {
    margin-right: 10px;
    margin-top: 10px;
    margin-left: auto;
    font-size: 12px;
    background: rgb(245, 249, 248);
    padding: 2px 10px;
    border-radius: 10px;
    color: rgb(2, 80, 65);
    font-family: 'Lato';
    font-weight: 600;
    letter-spacing: .4px;
    height: fit-content;
}
.def-name-con-crd {
    justify-content: center;
    flex-direction: column;
    display: flex;
    margin: auto;
    font-family: 'Lato';
    }
    .def_stat-of-dt {
    padding: 16px 0px;
    display: inline-flex;
    width: 100%;
    height: 60px;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    
}
    .con-of-cnt-data {
    padding: 5.5px 10px;
    background: rgba(0, 0, 0, 0.07);
    border-radius: 5px;
    color: rgb(38, 38, 39);
    width: 60%;
    text-align: center;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    }

    .con-of-dp-data {
    width: 40%;
}

button#dropdownMenuButton {
    background: no-repeat;
    border: none;
    height: 32px;
    padding: 5.5px;
    float: right;
    }

.all-auta-con {
    padding: 0px 24px;
    display: inline-flex;

}
.dropdown-toggle::after{
    display: none;
}

.dropdown-menu.show{
    border: none;
    border-radius: 10px;
}

a.com-for-lnk {
    text-decoration: none;
    color: #00000091;
    }
    .marg-for-temp{
        margin-left: 0px;
        margin-right: 30px;
    }
    .img-temp-of-mark{
        width: 168px;
        height: 166px;
    }










  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;

    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.btn-blck-in-auta-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(38, 38, 39);
    color: rgb(255, 255, 255);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'lato';
}

.btn-blck-in-auta-fcs:hover{
    background-color: rgb(71, 71, 71);
    transition: all 0.2s ease 0s;
}

.btn-blck-non-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
}

.btn-blck-non-fcs:hover{
    background-color: rgb(231, 231, 231);
    transition: all 0.2s ease 0s;
    color: black;
}

.modal-content{
    border-radius: 8px;
}

.btn-blck-non-fcs:focus{
    color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;
}
.btn-blck-non-fcs:active{

color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;

}


.con-of-temp-lst {
    display: inline-flex;
    width: 100%;
    padding: 5px 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    }

    .con-of-temp-lst:hover {
    background: #f2f2f28a;
    cursor: pointer;
}

.con-of-temp-lst>div {
    width: 50%;
    }

    span.temp-name {
    font-size: 14px;
}

span.crt-data-of-tmp {
    font-size: 10px;
    }
.row{
    margin-left: 0px;
    margin-right: 0px;
}








.btn-primary.focus, .btn-primary:focus{

    color: #fff;
    box-shadow: 0 0 0 0.2rem rgb(105 109 113 / 50%);
    background-color: rgb(38, 38, 39);
    border-color: rgb(38, 38, 39);

}





.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000b5;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
 
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}

iframe{
border: none;
}


.hide-scroll {
  background-color: #eee;
  width: 200px;
  height: 100px;
  border: 1px dotted black;
  overflow-y: scroll; /* Add the ability to scroll */
}

/* Hide scrollbar for Chrome, Safari and Opera */
.hide-scroll::-webkit-scrollbar {
    display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.hide-scroll {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}







.sel_of_tp_cat {
    padding: 3px 10px;
    background: white;
    width: fit-content;
    color: black;
    font-weight: 500;
    border-radius: 10px;
    display: inline-block;
    margin-top: 10px;
    font-size: 12px;
    border: 1px solid;
cursor:pointer;
}

.sel_of_tp_cat.sel_tag_dt {
    background: black;
    color: white;
}




.auta-main-dis-dash{
    width: 240px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    height: 300px;
    padding-bottom: 0px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    transition: .3s;
    margin-top: 20px;
}
.cp-round:after {
    border-top: solid 3px #564f4e;

}


.main-con-img-temp{
    flex: auto;
    min-height: 216px;
    display: inline-grid;
    width: 100%;
    background-size: cover;
    border-radius: 5px;
}
.con-of-cnt-data:hover{
cursor:pointer;
}


.modal-body {
    font-size: 14px;
    font-weight: 500;
}

.template-con-send {
    font-size: 15px;
    color: #670640;
    text-align: center;
    padding: 5px 20px;
    background: #ecdde6;
    border-radius: 40px;
    width: fit-content;
    margin: auto;
    margin-bottom: 1rem;
    font-weight: 400;
}
</style>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body style="
    margin: 0px;
">





<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">
<span id="con-of-err-msg"></span>
<span class="cls-err-menu" id="cncl-err-msg">
<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>
</span>
</div>


<div class="main-con-of-dash">

    
    <?php    require("../confige/header/theme-2.0-side.php");?>
    <div class="main-con-of-crm dsc-inln-flx">
        
 <?php    require("../confige/header/header-new.php");?>
     


       
    
 


<div class="auta-temp-name" id='main-loader-containre'>

<div class="head-of-inn-con">
        <span class="nm-auta-con">My Template</span>
    
    </div>


<div class="all-auta-con row" id="all_con_of_temp_data">



<div class="crt-new-auta-con" data-toggle="modal" id='crt_temp_step_one' data-target="#add_temp_in_auta" style="
    background: #8a0f85;height:300px;width:240px;
">
        
        <div class="new-crt-head">
        
        Create New Template
        </div>
        <div class="con-of-crt-new-img" style="
">
        <svg class="SVGInline-svg" style="width: 14px;height: 14px;fill: rgb(255, 255, 255);" width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M0 6c0-1.10457.89543-2 2-2h8c0 1.10457-.89543 2-2 2H0z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M6 0v8c0 1.10457-.89543 2-2 2V2c0-1.104569.89543-2 2-2z"></path></svg>
        </div>
    
    
    </div>
















</div>


</div>

 












    
    </div>




   


</div>






<div class="modal" id="add_temp_in_auta" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document" style="
    min-width: 80%;
">
    <div class="modal-content" style="height: 90vh;min-width: 80%;">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Template Library</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>


     <div class="modal-header" style="
    border-bottom: 0px;
    width: 100%;
    display: block;
">

    
<div class="sel_of_tp_cat tag_sel_temp">All</div>
<div class="sel_of_tp_cat tag_sel_temp">Managment</div>
<div class="sel_of_tp_cat tag_sel_temp">Account</div>
<div class="sel_of_tp_cat tag_sel_temp">Notify</div>
<div class="sel_of_tp_cat tag_sel_temp">Promotion</div>
<div class="sel_of_tp_cat tag_sel_temp">School</div>
<div class="sel_of_tp_cat tag_sel_temp">Product</div>
<div class="sel_of_tp_cat tag_sel_temp">Newsletter</div>
<div class="sel_of_tp_cat tag_sel_temp">Post</div>
<div class="sel_of_tp_cat tag_sel_temp">Statistic</div>
<div class="sel_of_tp_cat tag_sel_temp">Event</div>
<div class="sel_of_tp_cat tag_sel_temp">Shedule</div>
<div class="sel_of_tp_cat tag_sel_temp">Fashion</div>
<div class="sel_of_tp_cat tag_sel_temp">Organization</div>
<div class="sel_of_tp_cat tag_sel_temp">Donation</div>
<div class="sel_of_tp_cat tag_sel_temp">Launch</div>
<div class="sel_of_tp_cat tag_sel_temp">Personal</div>
<div class="sel_of_tp_cat tag_sel_temp">Page</div>


</div>
      <div class="modal-body row" id="app-of-temp-name-data" style="overflow:scroll;">
    
    


    <div class="auta-dis-on-dash"> <div class="main-con-name" style="
    background-image: url(https://d1oco4z2z1fhwp.cloudfront.net/templates/default/4351.jpg);
    background-size: cover;
">
    
    <span class="bdg-tp-btn"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
  <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/>
  <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"/>
</svg></span>  </div>  </div>
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
     
      </div>
    </div>
  </div>
</div>



<div class="modal" id="temp_prev_def" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none; background: rgba(51, 48, 48, 0.52);" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document" style="margin-top: 0px;margin-bottom: 0px;min-width: fit-content;">
    <div class="modal-content" style="height: 100vh;margin-top: 0px;min-width: 70%;">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Template Preview</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>


     
      <div class="modal-body row"  style="overflow:scroll;">
    

    <iframe src="http://localhost/new-editor/library/account%20credential.html" id="temp_prev_con_body" height="" width="800" title="Iframe Example"></iframe>
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" data-toggle="modal" data-target="#crt_new_temp_def_name">Create Template</button>
      </div>
    </div>
  </div>
</div>


<div class="modal" id="crt_new_temp_def_name" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;background: rgba(51, 48, 48, 0.52);" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Template Name</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="id_for_temp_name" placeholder="Enter Template Name">
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="click_to_new_temp">Create Template</button>
      </div>
    </div>
  </div>
</div>











<div class="modal" id="rename_temp_name_modal" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;background: rgba(51, 48, 48, 0.52);" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Rename Template <span id='rnm_temp_name'></span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <input type="text" class="ip-by-def-dsg" id="rename_temp_name" placeholder="Enter Template New Name">    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="svg_temp_rename">Rename Template</button>
      </div>
    </div>
  </div>
</div>




<div class="modal" id="send_temp_for_api" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;background: rgba(51, 48, 48, 0.52);" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Send Template For API</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
    <div class="content">
<p>send template for API used and use this template content using heptera api. this feature is gives ability to developer send dynamic content with designed template without learn code. <a class='hrf-doc-lnk' href="">Documentation</a></p>
</div>
<div class='template-con-send'></div>
<div class='content'>
<p>Once You're send template for API Used admin not able to change or modified in template. </p>
</div> 
      </div>
      <div class="modal-footer" style="
    border-top: 0px;
    padding-top: 0px;
">
<button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="send-for-api-connect" style="
    width: 100%;
">Connect With Developer Plateform</button>
</div>
    </div>
  </div>
</div>








<div class="modal" id="del_temp_from_lib" tabindex="-1" role="dialog" aria-labelledby="..." style="display: none;background: rgba(51, 48, 48, 0.52);" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Delete Template <span id='del_temp_name_dt'></span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">

    <input type="text" class="ip-by-def-dsg" id="del_cont_txt_ip" placeholder="Enter DELETE And Click">

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" id="del_temp_fin">Delete Template</button>
      </div>
    </div>
  </div>
</div>












</body></html>






<script type="text/javascript">

id='<?php echo $id;?>';
main_url_of_page="https://template.auftera.com/template/edit/temp-base/";




var temp_id_send_fr_api="";


function init_str_of_modal_temp(jsn_data){


str_app="";

for(const val of jsn_data){

    name_of_temp=val.temp_name;









    url=main_url_of_page+encodeURIComponent(name_of_temp)+".html";
  url_main="https://scr.auftera.com/scr-api/?url="+url+"&width=700&height=800";








str_app+='<div class="auta-dis-on-dash crt-new-temp-trg" data-toggle="modal" data-temp-name="'+name_of_temp+'"  data-target="#crt_new_temp_def_name"> <div class="main-con-name" style=" background-image: url('+url_main+'); background-size: cover; "> <span class="bdg-tp-btn trg_temp_prev_btn" data-toggle="modal" data-temp-name="'+name_of_temp+'"  data-target="#temp_prev_def" ><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16"> <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"></path> <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"></path> </svg></span>  </div>  </div>';


}


$("#app-of-temp-name-data").html(str_app);

}


$(document).on('click','.trg_temp_prev_btn',function(){



get_temp_name=$(this).attr("data-temp-name");

var encoded = encodeURIComponent(get_temp_name);



$("#temp_prev_con_body").attr("src","./edit/temp-base/"+encoded+".html");

        



})



	$(document).on('click','.crt-new-temp-trg',function(){



		decode_name_of_temp=$(this).attr('data-temp-name');

	});



tag_sel_arr=["all,"];


$(document).on('click','.tag_sel_temp',function(){
tag_sel_arr=[];


$(this).addClass('sel_tag_dt');
$(this).removeClass('tag_sel_temp');


$("#app-of-temp-name-data").html('<div class="cp-spinner cp-round"></div>');

	$('.sel_tag_dt').map(function() {


    
    tag_sel_arr.push($(this).html().toLowerCase());

  

  })

init_modal_data_of_tmp(tag_sel_arr);

})


	$(document).on('click','.sel_tag_dt',function(){

tag_sel_arr=[];
		$(this).removeClass('sel_tag_dt');
$(this).addClass('tag_sel_temp');

$("#app-of-temp-name-data").html('<div class="cp-spinner cp-round"></div>');

        $('.sel_tag_dt').map(function() {


    
    tag_sel_arr.push($(this).html().toLowerCase());

  

  })

if(tag_sel_arr.length<1){

	tag_sel_arr=["all,"];

}

 init_modal_data_of_tmp(tag_sel_arr);
	});

function init_modal_data_of_tmp(tag){


	tag=JSON.stringify(tag);

	console.log(tag);


$.ajax({
                url : "./ajaxfile/get_temp_by_tag.php",
                type: "POST",
                data : {tag_name:tag}
        }).done(function(response){ 

console.log(response);

init_str_of_modal_temp(JSON.parse(response));
        })


}


$(document).on("click","#click_to_new_temp",function(){
    


	name_of_temp=$("#id_for_temp_name").val();

    if(name_of_temp.length>0){

append_load_in_all_btn("#click_to_new_temp");
        $.ajax({
  type: "POST",
  url: "./crt-template/ajaxfile/vertempname.php",
  data: {temp_name_get:name_of_temp,type_temp:decode_name_of_temp,temp_crt_flg:1,path:"../../edit/temp-base/"}
}).done(function(response1) {
      

	console.log(response1);

	if(response1==1){
      temp_en_name=id+"^"+btoa(name_of_temp);
      window.location.href='./edit/?temp_id='+temp_en_name;
  }else{

      err_msg_data("Please Select Valid Name");
  }  
append_txt_of_lds("#click_to_new_temp");	
});

    }else{

err_msg_data("Enter Valid Name");
    }


});


$(document).on('click',"#crt_temp_step_one",function(){


init_modal_data_of_tmp(tag_sel_arr);

})


$(document).ready(function(){
$('[data-toggle="tooltip"]').tooltip();

    req_for_temp_det();
})



main_url_of_crt_temp="https://template.auftera.com/template/crt-template/crtedtemp/";


function init_str_of_all_temp(jsn_data){

str_app="";

for(const val of jsn_data){

name_of_temp_dis=atob(val.name.split("^")[1]);

src_of_bg_img="https://scr.auftera.com/scr-api/?url="+main_url_of_crt_temp+val.name+".html&width=700&height=800";


str_app+='<div class="auta-main-dis-dash"> <div class="main-con-img-temp" style="background-image:url('+src_of_bg_img+')"> <span class="bdg-tp-btn">'+name_of_temp_dis+'</span> </div> <div class="def_stat-of-dt"> <div class="con-of-cnt-data data_red_btn_ld" data-trg-url="./edit/?temp_id='+val.name+'">Edit</div> <div class="con-of-dp-data" style=""> <div class="dropdown" style=" height: 32px; "> <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <img src="https://res.cloudinary.com/heptera/image/upload/v1621831794/dashboard/more_horiz_black_24dp_kiwldy.svg" class="img-of-act"> </button> <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" x-placement="top-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(48px, -197px, 0px);"> <a class="dropdown-item data_red_btn_ld" data-trg-url="./edit/?temp_id='+val.name+'" href="#">Edit</a> <a class="dropdown-item rnm_trg_btn_act" href="#" data-toggle="modal" data-temp-name="'+val.name+'" data-target="#rename_temp_name_modal">Rename</a> <a class="dropdown-item click_to_copy" href="#" id="'+val.name+'">Copy</a> <a class="dropdown-item click_to_send_api" href="#" data-toggle="modal" data-temp-name="'+val.name+'" data-target="#send_temp_for_api">Send TO API</a> <a class="dropdown-item del_temp_name"  href="#" data-toggle="modal" data-temp-name="'+val.name+'" data-target="#del_temp_from_lib" style=" color: red; ">Delete</a>   </div> </div> </div> </div> </div>';
}

$("#all_con_of_temp_data").append(str_app);
}







$(document).on("click",".click_to_send_api",function(){

temp_id_send_fr_api=$(this).attr('data-temp-name');


$(".template-con-send").html(atob(temp_id_send_fr_api.split("^")[1]));


});




$(document).on("click","#send-for-api-connect",function(){
	
	console.log(temp_id_send_fr_api);
	append_load_in_all_btn("#send-for-api-connect");

$.ajax({
  type: "POST",
  url: "https://dev.auftera.com/dev/ajaxfile/send_for_api.php",
  data: {temp_id:temp_id_send_fr_api,id:id}
}).done(function(response1) {



	console.log(response1);



if(response1==1){

err_msg_data("SuccessFully Template Connected");


}else{


	err_msg_data("Something Wen't Wrong");

}

append_txt_of_lds("#send-for-api-connect");

});




});




function req_for_temp_det(){


    
$.ajax({
    url : 'temp_res/gettempdata.php',
    type: 'GET'
  }).done(function(response){ //
   
      
      console.log(response);
    var get_res_temp=JSON.parse(response);
    
    
 length_of_array=get_res_temp.length;

console.log(length_of_array);
    
   init_str_of_all_temp(get_res_temp);
    
  });
    




}


temp_old_name="";


$(document).on('click','.rnm_trg_btn_act',function(){


temp_old_name=$(this).attr('data-temp-name');

$("#rnm_temp_name").html(atob(temp_old_name.split("^")[1]));

})


$(document).on("click","#svg_temp_rename",function(){



rename_temp_name=$("#rename_temp_name").val();


append_load_in_all_btn("#svg_temp_rename");
$.ajax({
  type: "POST",
  url: "./crt-template/ajaxfile/rename_temp.php",
  data: {temp_old_name:temp_old_name,temp_new_name:rename_temp_name}
}).done(function(response1) {


if(response1==1){


location.reload();

        }else{



err_msg_data(response1);

        }
   append_txt_of_lds("#svg_temp_rename");
console.log(response1);
















   
});




});




$(document).on("click",".click_to_copy",function(){
name_of_temp=$(this).attr("id");
decode_name_of_temp=$(this).attr("id");

        $.ajax({
  type: "POST",
  url: "./crt-template/ajaxfile/vertempname.php",
  data: {temp_name_get:name_of_temp,type_temp:decode_name_of_temp,temp_crt_flg:0}
}).done(function(response1) {

    console.log(response1);
    if(response1==1){

	    $("#main-loader-containre").addClass("main-loader-containre-act");
$("#main-loader-containre").html('<div class="cp-spinner cp-round"></div>');

location.reload();

	}else{

name_dec=atob(decode_name_of_temp.split("^")[1])+"-copy";
err_msg_data(name_dec+" Name Present In Folder");
	}
    
    
   
});


})


del_temp="";


$(document).on("click",".del_temp_name",function(){
del_temp=$(this).attr("data-temp-name");


$("#del_temp_name_dt").html(atob(del_temp.split("^")[1]));

});










$(document).on("click","#del_temp_fin",function(){


del_conf_txt=$("#del_cont_txt_ip").val();


console.log(del_temp);

if(del_conf_txt=="DELETE"){

append_load_in_all_btn("#del_temp_fin");

$.ajax({
  type: "POST",
  url: "./crt-template/ajaxfile/del_temp.php",
  data: {temp_old_name:del_temp}
}).done(function(response1) {



console.log(response1);
   
if(response1==1){

$("#main-loader-containre").addClass("main-loader-containre-act");
$("#main-loader-containre").html('<div class="cp-spinner cp-round"></div>');

location.reload();
   }else{

err_msg_data(response1);
   }

append_txt_of_lds("#del_temp_fin");

});

}else{

err_msg_data("Enter DELETE Excatly");

}

});







$(document).on("click",".data_red_btn_ld",function(){

$("#main-loader-containre").addClass("main-loader-containre-act");
$("#main-loader-containre").html('<div class="cp-spinner cp-round"></div>');

window.location = $(this).attr('data-trg-url');

})



append_txt_that_get_clck="";

function append_load_in_all_btn(selector){




append_txt_that_get_clck=$(selector).html();

$(selector).prop("disabled",true);

$(selector).html('<div class="cp-spinner cp-round"></div>');

}



function append_txt_of_lds(selector){

$(selector).prop("disabled",false);

$(selector).html(append_txt_that_get_clck);


}



function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}


$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})




</script>
