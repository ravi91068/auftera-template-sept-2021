<?php

error_reporting(E_ALL);

session_start();

$id=$_SESSION["id"];
$servername = "studio.cnenb266gjbe.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";


$dbname = "imagedir";

$imagedir = mysqli_connect($servername, $username, $password,$dbname);

$select_dir="SELECT * FROM imagedirname WHERE id='$id'";

$slected_dir = $imagedir->query($select_dir);


while($row = $slected_dir->fetch_assoc()){
      $dbdata[]=$row;
  }
$datavar=json_encode($dbdata);


?>


<html>
<head>

<link rel="stylesheet" href="//unpkg.com/grapesjs/dist/css/grapes.min.css">
<link rel="stylesheet" type="text/css" href="https://grapesjs.com/stylesheets/grapesjs-preset-newsletter.css?v=0.2.21">
<script src="//unpkg.com/grapesjs"></script>
<script type="text/javascript" src='https://grapesjs.com/js/grapesjs-preset-newsletter.min.js?v=0.2.21'></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<script src="https://cdn.ckeditor.com/4.14.1/standard-all/ckeditor.js"></script>
<script src="https://cdn.jsdelivr.net/npm/grapesjs-plugin-ckeditor@0.0.9/dist/grapesjs-plugin-ckeditor.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript" src='./emb/gps-bg.js'></script>

<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">

<style type="text/css">

body{
	margin:0px;
	font-family: 'lato';
	font-weight: 400;

}


#gjs {
  
}

/* Reset some default styling */
.gjs-cv-canvas {
  top: 0;
  width: 100%;
  height: 100%;
}

.gjs-block {
  width: auto;
  height: auto;
  min-height: auto;
}

.panel__top {
  padding: 0;
  width: 100%;
  display: flex;
  position: initial;
  justify-content: center;
  justify-content: space-between;
}
.panel__basic-actions {
  position: initial;
}

.editor-row {
  display: flex;
  justify-content: flex-start;
  align-items: stretch;
  flex-wrap: nowrap;
  height: 84vh;
}

.editor-canvas {
  flex-grow: 1;
}

.panel__right {
  flex-basis: 230px;
  position: relative;
  overflow-y: auto;
  background: #332e32fa;
}

.panel__switcher {
	background: #4a154b !important;
  position: initial;
}

.gjs-pn-btn{
	font-size: 2vh;
    margin-right: 5px;
    border-radius: 2px;
    padding: 3vh;
    color: white;
   

}

.panel__devices {
	background: #4a154b !important;
  position: initial;
}

.gjs-pn-panel{
	padding: 0px;
}

.gjs-pn-btn.gjs-pn-active{
	box-shadow: none;
}





.panel__basic-actions{
	background: #4a154b !important;
}




.panel__switcher.gjs-pn-panel.gjs-pn-panel-switcher.gjs-one-bg.gjs-two-color {
    width: 30%;
}


.panel__switcher.gjs-pn-panel.gjs-pn-panel-switcher.gjs-one-bg.gjs-two-color>.gjs-pn-buttons>span.gjs-pn-btn{
	width: 33%;
}








.editor-canvas {
    max-width: 70%;
}
.panel__right {
    min-width: 30%;
    background: #f3f3f3;
    padding-bottom: 2vh;

    }



.gjs-layer {
    font-weight: lighter;
    text-align: left;
    position: relative;
    background-color: rgba(0,0,0,.1);
    font-size: .75rem;
}

.gjs-category-title, .gjs-layer-title, .gjs-block-category .gjs-title, .gjs-sm-sector .gjs-sm-title, .gjs-clm-tags .gjs-sm-title
{
	font-weight: 500;

}
.gjs-sm-sector .gjs-sm-field input, .gjs-clm-tags .gjs-sm-field input, .gjs-sm-sector .gjs-clm-select input, .gjs-clm-tags .gjs-clm-select input, .gjs-sm-sector .gjs-clm-field input, .gjs-clm-tags .gjs-clm-field input, .gjs-sm-sector .gjs-sm-field select, .gjs-clm-tags .gjs-sm-field select, .gjs-sm-sector .gjs-clm-select select, .gjs-clm-tags .gjs-clm-select select, .gjs-sm-sector .gjs-clm-field select, .gjs-clm-tags .gjs-clm-field select{
	color: rgb(12 12 12 / 70%);

}

.gjs-sm-properties{
	font-weight: 500;

}

.gjs-clm-tags {
    font-weight: 400;
}
#gjs {
  border: none;
}
/* Theming */

/* Primary color for the background */
.gjs-one-bg {
  background-color:#f3f3f3fa;
}

/* Secondary color for the text color */
.gjs-two-color {
  color: #191616;
}

/* Tertiary color for the background */
.gjs-three-bg {
  background-color: #ec5896;
  color: white;
}

/* Quaternary color for the text color */
.gjs-four-color,
.gjs-four-color-h:hover {
  color: #ec5896;
}


.panel__top{
	background: #4a154b;
}


.gjs-block.gjs-one-bg.gjs-four-color-h {
    width: 28%;
    background: white;
    }
    .gjs-block-label {
    font-family: 'Lato';
    font-weight: 700;
    font-size: 12px;
}

.gjs-pn-panel.gjs-pn-devices-c.gjs-one-bg.gjs-two-color>.gjs-pn-buttons {
    display: none;
    }

    .gjs-block.gjs-one-bg.gjs-four-color-h{
    	width: 28%;
    }


.panel_bottom {
    height: 8vh;
    width: 100%;
    background: #4a154b;
    padding: 2vh;
    top: 92vh;
    position: fixed;
    z-index: 10000;

  }
button.bottom-act-btn {
    font-size: 13px;
    border: none;
    background: white;
    border-radius: 5px;
    height: 4vh;
    }

    .gjs-label {
    line-height: 18px;
    color: black;
    font-weight: 500;
}
.gjs-trt-trait{
	display: block;
}
.gjs-label-wrp{
	margin-bottom: 10px;
}


    .desg-of-sel-img-fold {
    background: #f3f3f3 !important;
    display: inline-flex;

width:100%;
}

.sel_img_for_sco{

	
    margin-left: 3%;
    background: white;
    border-radius: 10px;
    margin-top: 20px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-bottom: 10px;
    height: auto;
}

img.lbl_for_icon {
    width: 100%;
    padding: 12px;
    }

    .gjs-frame{
    	width: 90%;
    }

    div#gjs {
    padding-bottom: 2vh;
    background: rgb(207 207 207);
  }



img.sel_img_chg {
   width: auto;
    height: auto;
    position: absolute;
    top: 0;
    bottom: 0;
    max-height: 100%;
    max-width: 100%;
    margin: auto;
}
.img-con-of-sel {
   min-width: 100px;
    min-height: 100px;
    position: relative;
    margin: 10px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    background: white;
    padding: 0px;
    max-width: 100px;
    display: flex;
    justify-content: center;
}
</style>

</head>
<body>

	<div class="panel__top">
    <div class="panel__basic-actions"></div>
    <div class="panel__devices"></div>
    <div class="panel__switcher"></div>
</div>
<div class="editor-row">
  <div class="editor-canvas">
    <div id="gjs">

<?php 

$file_name=$_GET['temp_id'];



echo file_get_contents("../crt-template/crtedtemp/".$file_name.".html");

?>

</div>
  </div>
  <div class="panel__right">
    <div class="blocks-container" ></div>
    <div class="styles-container" style='display: none;'></div>
    
    <div class="layers-container" style='display: none;'></div>
    <div class="traits-container" style='display: none;'></div>
  </div>
</div>


<div class="panel_bottom">
    <button class="bottom-act-btn data_red_btn_ld"  data-trg-url="../../template/">
    
    
    

    
    Back To Dashboard</button>

 <button class="bottom-act-btn" style="
    float: right;
" id='save_and_save'>Save Template</button>

</div>

</body>



</html>
<script type="text/javascript">








$(document).on("click",".data_red_btn_ld",function(){


window.location = $(this).attr('data-trg-url');

})




















const myPlugin = editor => {
  editor.DomComponents.addType('image', {
    
    model: {
    defaults: {
      traits: [
      {
          type: 'input',
          name: 'src',
          label: 'Image Link',
      },
        {
          type: 'image-next-2',
          name: 'src',
          label: 'New href',
        },
      ]
    }
  }
  });
}

const bg_style = editor => {
 

const styleManager = editor.StyleManager;
styleManager.addSector('div-only-sector', {
    name: 'Setting',
    open: true,
    buildProps: ['width', 'height'],
    properties: [{
        name: 'Visibility',
        property: 'display',
        type: 'radio',
        
    }]
});
}


const myPlugin_cell = editor => {
  editor.DomComponents.addType('default', {
    
    model: {
    defaults: {
      traits: [
      {
          type: 'input',
          name: 'background-image',
          label: 'Image Link',
      },
        {
          type: 'image-next-2',
          name: 'src',
          label: 'New href',
        },
  
      ]
    }
  }
  });
}

const myPlugin_soc = editor => {
  

editor.DomComponents.addType('image-link', {
  model: {
    defaults: {
      traits: [

        {
          type: 'input',
          name: 'href',
          label: 'Social Link',
        },
        {
          type: 'input',
          name: 'src',
          label: 'Social Icon Link',
        },
        {
          type: 'image-next-soc',
          
          label: 'Select Icon',
        }
      ]
    }
  }
});
}

const editor = grapesjs.init({
  // Indicate where to init the editor. You can also pass an HTMLElement
  container: '#gjs',
  // Get the content for the canvas directly from the element
  // As an alternative we could use: `components: '<h1>Hello World Component!</h1>'`,
  fromElement: true,
  // Size of the editor
  height: '84vh',
  width: 'auto',
  avoidInlineStyle : false,
  plugins: ['gjs-plugin-ckeditor','gjs-preset-newsletter','grapesjs-mjml',myPlugin,myPlugin_soc,myPlugin_cell,bg_style],
  pluginsOpts: {
          "gjs-plugin-ckeditor": {
          options: { language: "en" }
          },
          'gjs-preset-newsletter': {
          modalTitleImport: 'Import template',
          // ... other options
        }
        },
  // Disable the storage manager for the moment
  storageManager: false,
  // Avoid any default panel
  





  blockManager: {
    appendTo: '.blocks-container',
    blocks: [
      {
        id: 'section', // id is mandatory
        label: '<b>Section</b>', // You can use HTML/SVG inside labels
        attributes: { class:'gjs-block-section' },
        content: '<h1 class="heading">Insert title here</h1><p class="paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>',
      }, {
        id: 'text',
        label: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 224 180"><defs><style>.a{fill:#c7c7c7;}</style></defs><title>text</title><rect class="a" x="48" y="46" width="128" height="4"></rect><rect class="a" x="48" y="56" width="128" height="4"></rect><rect class="a" x="48" y="66" width="128" height="4"></rect><rect class="a" x="48" y="76" width="128" height="4"></rect><rect class="a" x="48" y="86" width="128" height="4"></rect><rect class="a" x="48" y="96" width="128" height="4"></rect><rect class="a" x="48" y="106" width="128" height="4"></rect><rect class="a" x="48" y="116" width="128" height="4"></rect><rect class="a" x="48" y="126" width="128" height="4"></rect><rect class="a" x="48" y="136" width="88" height="4"></rect></svg> Text',
        content: "<table> <tbody> <tr> <td style='padding-top:0px;padding-bottom:0px;' class='edit text' style='max-width:100%;padding:20px;' id='546' width='50%'> <p style='padding:20px;'> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of</p> </td> </tr> </tbody> </table>",
      }, {
        id: 'image',
        label: 'Image',
        // Select the component once it's dropped
        select: true,
        // You can pass components as a JSON instead of a simple HTML string,
        // in this case we also use a defined component type `image`
        content: { type: 'image' },
        // This triggers `active` event on dropped components and the `image`
        // reacts by opening the AssetManager
        activate: true,
      }
    ]
  },



  layerManager: {
    appendTo: '.layers-container'
  },
  // We define a default panel as a sidebar to contain layers
  panels: {
    defaults: [{
      id: 'layers',
      el: '.panel__right',
      // Make the panel resizable
      resizable: {
        maxDim: 350,
        minDim: 200,
        tc: 0, // Top handler
        cl: 1, // Left handler
        cr: 0, // Right handler
        bc: 0, // Bottom handler
        // Being a flex child we need to change `flex-basis` property
        // instead of the `width` (default)
        keyWidth: 'flex-basis',
      },
    }]
  },


  panels: {
    defaults: [
      // ...
      {
        id: 'panel-switcher',
        el: '.panel__switcher',
        buttons: [ {
            id: 'show-block',
            active: true,
            label: '<svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="#FFFFFF"><g><rect fill="none" height="24" width="24"/></g><g><g><rect height="4" opacity=".3" width="4" x="5" y="5"/><rect height="4" opacity=".3" width="4" x="5" y="15"/><rect height="4" opacity=".3" width="4" x="15" y="15"/><rect height="4" opacity=".3" width="4" x="15" y="5"/><path d="M3,21h8v-8H3V21z M5,15h4v4H5V15z"/><path d="M3,11h8V3H3V11z M5,5h4v4H5V5z"/><path d="M13,21h8v-8h-8V21z M15,15h4v4h-4V15z"/><path d="M13,3v8h8V3H13z M19,9h-4V5h4V9z"/></g></g></svg>',
            command: 'show-block',
            togglable: false,
        },
        {
            id: 'show-style',
            active: true,
            label: '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#FFFFFF"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M15.22 4.75L7.87 7.79l4.96 11.96 7.35-3.05-4.96-11.95zM11 10c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z" opacity=".3"/><path d="M3.87 11.18l-2.43 5.86c-.41 1.02.08 2.19 1.09 2.61l1.34.56v-9.03zm18.16 4.77L17.07 3.98c-.31-.75-1.04-1.21-1.81-1.23-.26 0-.53.04-.79.15L7.1 5.95c-.75.31-1.21 1.03-1.23 1.8-.01.27.04.54.15.8l4.96 11.97c.31.76 1.05 1.22 1.83 1.23.26 0 .52-.05.77-.15l7.36-3.05c1.02-.42 1.51-1.59 1.09-2.6zm-9.2 3.8L7.87 7.79l7.35-3.04h.01l4.95 11.95-7.35 3.05z"/><circle cx="11" cy="9" r="1"/><path d="M9.33 21.75l-3.45-8.34v6.34c0 1.1.9 2 2 2h1.45z"/></svg>',
            command: 'show-styles',
            togglable: false,
        },
        {
            id: 'show-layers',
            active: true,
            label: '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#FFFFFF"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M6.26 9L12 13.47 17.74 9 12 4.53z" opacity=".3"/><path d="M19.37 12.8l-7.38 5.74-7.37-5.73L3 14.07l9 7 9-7zM12 2L3 9l1.63 1.27L12 16l7.36-5.73L21 9l-9-7zm0 11.47L6.26 9 12 4.53 17.74 9 12 13.47z"/></svg>',
            command: 'show-layers',
            // Once activated disable the possibility to turn it off
            togglable: false,
          },
          {
            id: 'show-traits',
            active: true,
            label: '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#FFFFFF"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19.28 8.6l-.7-1.21-1.27.51-1.06.43-.91-.7c-.39-.3-.8-.54-1.23-.71l-1.06-.43-.16-1.13L12.7 4h-1.4l-.19 1.35-.16 1.13-1.06.44c-.41.17-.82.41-1.25.73l-.9.68-1.05-.42-1.27-.52-.7 1.21 1.08.84.89.7-.14 1.13c-.03.3-.05.53-.05.73s.02.43.05.73l.14 1.13-.89.7-1.08.84.7 1.21 1.27-.51 1.06-.43.91.7c.39.3.8.54 1.23.71l1.06.43.16 1.13.19 1.36h1.39l.19-1.35.16-1.13 1.06-.43c.41-.17.82-.41 1.25-.73l.9-.68 1.04.42 1.27.51.7-1.21-1.08-.84-.89-.7.14-1.13c.04-.31.05-.52.05-.73 0-.21-.02-.43-.05-.73l-.14-1.13.89-.7 1.1-.84zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4z" opacity=".3"/><path d="M19.43 12.98c.04-.32.07-.64.07-.98 0-.34-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.09-.16-.26-.25-.44-.25-.06 0-.12.01-.17.03l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.06-.02-.12-.03-.18-.03-.17 0-.34.09-.43.25l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.09.16.26.25.44.25.06 0 .12-.01.17-.03l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.06.02.12.03.18.03.17 0 .34-.09.43-.25l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zm-1.98-1.71c.04.31.05.52.05.73 0 .21-.02.43-.05.73l-.14 1.13.89.7 1.08.84-.7 1.21-1.27-.51-1.04-.42-.9.68c-.43.32-.84.56-1.25.73l-1.06.43-.16 1.13-.2 1.35h-1.4l-.19-1.35-.16-1.13-1.06-.43c-.43-.18-.83-.41-1.23-.71l-.91-.7-1.06.43-1.27.51-.7-1.21 1.08-.84.89-.7-.14-1.13c-.03-.31-.05-.54-.05-.74s.02-.43.05-.73l.14-1.13-.89-.7-1.08-.84.7-1.21 1.27.51 1.04.42.9-.68c.43-.32.84-.56 1.25-.73l1.06-.43.16-1.13.2-1.35h1.39l.19 1.35.16 1.13 1.06.43c.43.18.83.41 1.23.71l.91.7 1.06-.43 1.27-.51.7 1.21-1.07.85-.89.7.14 1.13zM12 8c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4zm0 6c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/></svg>',
            command: 'show-traits',
            togglable: false,
        }],
      },
      {
        id: 'panel-devices',
        el: '.panel__devices',
        buttons: [{
            id: 'device-desktop',
            label: '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#FFFFFF"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M3 4h18v12H3z" opacity=".3"/><path d="M21 2H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h7v2H8v2h8v-2h-2v-2h7c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H3V4h18v12z"/></svg>',
            command: 'set-device-desktop',
            active: true,
            togglable: false,
          }, {
            id: 'device-mobile',
            label: '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#FFFFFF"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M7 5h10v14H7z" opacity=".3"/><path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"/></svg>',
            command: 'set-device-mobile',
            togglable: false,
        }],
      }
    ]
  },
  // The Selector Manager allows to assign classes and
  // different states (eg. :hover) on components.
  // Generally, it's used in conjunction with Style Manager



  deviceManager: {
    devices: [{
        name: 'Desktop',
        width: '', // default size
      }, {
        name: 'Mobile',
        width: '420px', // this value will be used on canvas width
        widthMedia: '480px', // this value will be used in CSS @media
    }]
  },
  // ...
  

  // but it's not mandatory
  selectorManager: {
    appendTo: '.styles-container'
  },
  styleManager: {
    appendTo: '.styles-container',
    sectors: [{
        name: 'Dimension',
        open: false,
        // Use built-in properties
        buildProps: ['width', 'min-height', 'padding'],
        // Use `properties` to define/override single property
        properties: [
          {
            // Type of the input,
            // options: integer | radio | select | color | slider | file | composite | stack
            type: 'integer',
            name: 'The width', // Label for the property
            property: 'width', // CSS property (if buildProps contains it will be extended)
            units: ['px', '%'], // Units, available only for 'integer' types
            defaults: 'auto', // Default value
            min: 0, // Min value, available only for 'integer' types
          }
        ]
      },{
        name: 'Extra',
        open: false,
        buildProps: ['background-color', 'box-shadow', 'custom-prop'],
        properties: [
          {
            id: 'custom-prop',
            name: 'Custom Label',
            property: 'font-size',
            type: 'select',
            defaults: '32px',
            // List of options, available only for 'select' and 'radio'  types
            options: [
              { value: '12px', name: 'Tiny' },
              { value: '18px', name: 'Medium' },
              { value: '32px', name: 'Big' },
            ],
         }
        ]
      }]
  },
    



  traitManager: {
    appendTo: '.traits-container',
  },


});


editor.Commands.add('set-device-desktop', {
  run: editor => editor.setDevice('Desktop')
});
editor.Commands.add('set-device-mobile', {
  run: editor => editor.setDevice('Mobile')
});



editor.TraitManager.addType('image-next-soc', {
  // Expects as return a simple HTML string or an HTML element
  createInput({ trait }) {
    // Here we can decide to use properties from the trait
    const traitOpts = trait.get('options') || [];
    const options = traitOpts.length ? traitOpts : [
      { id: 'url', name: 'URL' },
      { id: 'email', name: 'Email' }
    ];

    // Create a new element container and add some content
    const el = document.createElement('div');
    el.innerHTML = `
      
      <div  class="desg-of-sel-img-fold  href-next__url-inputs" style="display: block;" >
        


<img src="https://template.auftera.com/template/iconfolder/facebook-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/twitter-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/blogger-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/fbmessenger-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/flickr-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/google-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/instagram-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/medium-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/odnoklassniki-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/periscope-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/pinterest-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/slideshare-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/snapchat-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/telegram-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/tumblr-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/viber-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vimeo-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vk-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/whatsapp-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/youtube-flat.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/facebook-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/twitter-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/blogger-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/fbmessenger-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/flickr-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/google-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/instagram-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/medium-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/odnoklassniki-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/periscope-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/pinterest-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/slideshare-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/snapchat-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/telegram-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/tumblr-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/viber-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vimeo-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vk-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/whatsapp-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/youtube-grey.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/facebook-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/twitter-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/blogger-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/fbmessenger-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/flickr-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/google-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/instagram-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/medium-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/odnoklassniki-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/periscope-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/pinterest-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/slideshare-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/snapchat-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/telegram-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/tumblr-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/viber-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vimeo-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vk-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/whatsapp-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/youtube-logos.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/facebook-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/twitter-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/blogger-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/fbmessenger-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/flickr-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/google-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/instagram-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/medium-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/odnoklassniki-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/periscope-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/pinterest-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/slideshare-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/snapchat-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/telegram-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/tumblr-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/viber-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vimeo-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vk-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/whatsapp-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/youtube-outlined.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/facebook-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/twitter-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/blogger-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/fbmessenger-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/flickr-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/google-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/instagram-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/medium-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/odnoklassniki-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/periscope-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/pinterest-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/slideshare-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/snapchat-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/telegram-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/tumblr-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/viber-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vimeo-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vk-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/whatsapp-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/youtube-outlined_white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/facebook-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/twitter-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/blogger-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/fbmessenger-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/flickr-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/google-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/instagram-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/medium-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/odnoklassniki-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/periscope-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/pinterest-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/slideshare-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/snapchat-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/telegram-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/tumblr-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/viber-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vimeo-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vk-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/whatsapp-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/youtube-round.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/facebook-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/twitter-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/blogger-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/fbmessenger-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/flickr-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/google-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/instagram-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/medium-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/odnoklassniki-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/periscope-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/pinterest-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/slideshare-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/snapchat-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/telegram-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/tumblr-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/viber-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vimeo-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vk-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/whatsapp-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/youtube-square.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/facebook-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/twitter-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/blogger-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/fbmessenger-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/flickr-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/google-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/instagram-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/medium-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/odnoklassniki-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/periscope-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/pinterest-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/slideshare-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/snapchat-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/telegram-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/tumblr-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/viber-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vimeo-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/vk-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/whatsapp-white.png" height="60px" class="sel_img_for_sco"> <img src="https://template.auftera.com/template/iconfolder/youtube-white.png" height="60px" class="sel_img_for_sco"> 
      </div>
      
    `;

return el
    // Let's make our content interactive
    
  }

});




var blockManager = editor.BlockManager;
    
    blockManager.add('name-block', {
        label: '<img src="https://res.cloudinary.com/heptera/image/upload/v1627142227/editor/social-media_3_rlhmdf.png" class="lbl_for_icon">Social Icon',
        content: '<a   draggable="true" data-highlightable="1" style="display:inline-block;padding:5px;min-height:50px;min-width:50px;" id="inbaci" class=""><img data-gjs-type="image-link"   src="https://img.auftera.com/images/497889959^dW5kZWZpbmU=^0.png" height="50px" ></a>',
        category: 'Social Icon',
        attributes: {
            title: '',
            class: 'gjs-fonts gjs-custom-field'
        }
    });

editor.on('load', function() {
        //Insert loading code here
        blockManager.getAll().reset();

        
    });







editor.Commands.add('show-layers', {
  getRowEl(editor) { return editor.getContainer().closest('.editor-row'); },
  getLayersEl(row) { return row.querySelector('.layers-container') },

  run(editor, sender) {
    const lmEl = this.getLayersEl(this.getRowEl(editor));
    lmEl.style.display = '';
  },
  stop(editor, sender) {
    const lmEl = this.getLayersEl(this.getRowEl(editor));
    lmEl.style.display = 'none';
  },
});
editor.Commands.add('show-styles', {
  getRowEl(editor) { return editor.getContainer().closest('.editor-row'); },
  getStyleEl(row) { return row.querySelector('.styles-container') },

  run(editor, sender) {
    const smEl = this.getStyleEl(this.getRowEl(editor));
    smEl.style.display = '';
  },
  stop(editor, sender) {
    const smEl = this.getStyleEl(this.getRowEl(editor));
    smEl.style.display = 'none';
  },
});

editor.Commands.add('show-traits', {
  getTraitsEl(editor) {
    const row = editor.getContainer().closest('.editor-row');
    return row.querySelector('.traits-container');
  },
  run(editor, sender) {
    this.getTraitsEl(editor).style.display = '';
  },
  stop(editor, sender) {
    this.getTraitsEl(editor).style.display = 'none';
  },
});


editor.Commands.add('show-block', {
  getRowEl(editor) { return editor.getContainer().closest('.editor-row'); },
  getStyleEl(row) { return row.querySelector('.blocks-container') },

  run(editor, sender) {
    const smEl = this.getStyleEl(this.getRowEl(editor));
    smEl.style.display = '';
  },
  stop(editor, sender) {
    const smEl = this.getStyleEl(this.getRowEl(editor));
    smEl.style.display = 'none';
  },
});




editor.Panels.addPanel({
  id: 'panel-top',
  el: '.panel__top',
});
editor.Panels.addPanel({
  id: 'basic-actions',
  el: '.panel__basic-actions',
  buttons: [
    {
      id: 'visibility',
      active: true, // active by default
      className: 'btn-toggle-borders',
      label: '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#FFFFFF"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M7 3h2v2H7zm0 16h2v2H7zM3 3h2v2H3zm16 0h2v2h-2zm0 4h2v2h-2zm0 4h2v2h-2zM3 7h2v2H3zm0 12h2v2H3zm16 0h2v2h-2zm0-4h2v2h-2zM3 15h2v2H3zm0-4h2v2H3zm4 0h2v2H7zm8 0h2v2h-2zm-4 8h2v2h-2zm4 0h2v2h-2zm0-16h2v2h-2zm-4 0h2v2h-2zm0 4h2v2h-2zm0 8h2v2h-2zm0-4h2v2h-2z"/></svg>',
      command: 'sw-visibility', // Built-in command
    }
  ],
});





    
con_of_all_fold_data=JSON.parse('<?php echo $datavar;?>');





editor.TraitManager.addType('image-next-2', {
  // Expects as return a simple HTML string or an HTML element
  createInput({ trait }) {
    // Here we can decide to use properties from the trait
    const traitOpts = trait.get('options') || [];
    const options = traitOpts.length ? traitOpts :con_of_all_fold_data;

    // Create a new element container and add some content
    const el = document.createElement('div');
    el.innerHTML = `
      <select class="href-next__type">
        ${options.map(opt => `<option value="${opt.dir}">${atob(opt.dir.split("^")[1])}</option>`).join('')}
      </select>
      <div  class="desg-of-sel-img-fold href-next__url-inputs row" id="img-of-fold-data">
       <div class="img-con-of-sel">      <img src="https://img.auftera.com/images/497889959^dW5kZWZpbmU=^0.png" height="100px" class="sel_img_chg"></div>
      </div>
     
    `;

    // Let's make our content interactive
    const inputsUrl = el.querySelector('.href-next__url-inputs');
    const inputsEmail = el.querySelector('.href-next__email-inputs');
    const inputType = el.querySelector('.href-next__type');
    inputType.addEventListener('change', ev => {
      console.log(ev.target.value);


init_img_of_fold_data(ev.target.value);

     
    });

    return el;
  },
  

});



function init_img_of_fold_data(fold_id){



$.ajax({
  type: "POST",
  url: "./ajaxfile/getdirimg.php",
  data: {dir_name:fold_id}
}).done(function(response1) {


	init_str_of_sel_img_fold(JSON.parse(response1));
})

}


function init_str_of_sel_img_fold(jsn_data){
str_app="";

	for (const val of jsn_data){


		str_app+='<div class="img-con-of-sel">      <img src="https://img.auftera.com/images/'+val+'" height="100px" class="sel_img_chg"></div>';

	}

$("#img-of-fold-data").html(str_app);
}


$(document).ready(function(){


$(".gjs-pn-panels").empty();



})

id_soc_img=0;

$(document).on('click',".sel_img_for_sco",function(){

console.log(editor.getSelected().get('src'));
	

editor.getSelected().setAttributes({src: $(this).attr('src')});


})
$(document).on('click','.img-con-of-sel',function(){

	
if(editor.getSelected().is('cell')){



editor.getSelected().setAttributes({background: $(this).attr('src')});

}else{

	editor.getSelected().set("src", $(this).children("img").attr('src'));


	}

})

$(document).on('click','.btn-open-export',function(){




})

function rem_sel_cls(){



editor.getSelected().set("class", "nmn");


	return true;
}

$(document).on('click','#save_and_save',function(){



	
$(".gjs-frame").contents().find("html").find(".gjs-selected").removeClass("gjs-selected");


console.log($(".gjs-frame").contents().find("html").html());

})

$(document).on('click','#save_and_ext',function(){






out_put_val=editor.runCommand('gjs-get-inlined-html');

	console.log(out_put_val);

})





temp_id_name='<?php echo $file_name;?>';


function save_data_temp(){

append_load_in_all_btn("#save_and_save");
 $(".gjs-frame").contents().find("html").find(".gjs-selected").removeClass("gjs-selected");
        con_to_save=$(".gjs-frame").contents().find("html").html();

        $.post("test2.php",
  {

    content: con_to_save,
   edited_id: temp_id_name
  },
  function(data,status){
     

append_txt_of_lds("#save_and_save");
    });




}

setInterval(function() {
    save_data_temp();
}, 30 * 1000);

$("#save_and_save").click(function(){


save_data_temp();
});












append_txt_that_get_clck="";



function append_load_in_all_btn(selector){




append_txt_that_get_clck=$(selector).html();

$(selector).prop("disabled",true);

$(selector).html('<div class="cp-spinner cp-round"></div>');

}



function append_txt_of_lds(selector){

$(selector).prop("disabled",false);

$(selector).html(append_txt_that_get_clck);


}









function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}


$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})






</script>
