
<?php


$temp_id=$_GET['temp_id'];

?>

<html>
<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@100;300;400;500;600;700&family=Roboto&display=swap" rel="stylesheet">
<style type="text/css">
*,
*:before,
*:after {
  box-sizing: border-box;
}
body{
	font-family: 'IBM Plex Sans', sans-serif;
letter-spacing:0.2px;
}

html,
body {
  width: 100%;
  height: 100%;
  min-height: 100%;
}

body {
	margin: 0px;
  background: #fff;
  font-size: 14px;
}

.device,
.device *,
.device *:after,
.device *:before {
  backface-visibility: hidden;
}

.device {
  border: 2px solid #333;
  background: #fff;
  border-radius: 40px;
  box-shadow: 6px 6px 0px rgba(0, 0, 0, 0.05);
  transition: all 0.65s cubic-bezier(0.19, 1, 0.22, 1);
}

.device__header {
  position: absolute;
  top: 36px;
  left: 50%;
  margin-left: -24px;
  width: 48px;
  height: 4.8px;
  background: #333;
  border-radius: 2.4px;
  transition: all 0.65s cubic-bezier(0.19, 1, 0.22, 1);
}

.device__header:after,
.device__header:before {
  position: absolute;
  content: "";
  transition: all 0.65s cubic-bezier(0.19, 1, 0.22, 1);
}

.device__header:before {
  top: -0.8px;
  left: -14.4px;
  width: 6.4px;
  height: 6.4px;
  border-radius: 3.2px;
  border: 1px solid #333;
  background: #333;
}

.device__header:after {
  top: -20px;
  left: 50%;
  margin-left: -4.8px;
  width: 9.6px;
  height: 9.6px;
  border-radius: 4.8px;
  border: 1px solid #333;
  background: #333;
}

.device__content {
  width: 256px;
  overflow: scroll;
  height: 454.4px;
  background: #fff;
  border: 1px solid #333;
  border-radius: 2.4px;
  margin: 64px 12px 64px 12px;
  transition: all 0.65s cubic-bezier(0.19, 1, 0.22, 1);
}

.device__footer {
  position: absolute;
  bottom: 8px;
  left: 50%;
  margin-left: -24px;
  width: 48px;
  height: 48px;
  border-radius: 24px;
  border: 1px solid #333;
  transition: all 0.65s cubic-bezier(0.19, 1, 0.22, 1);
}

.device__footer:after {
  content: "";
  position: absolute;
  top: 50%;
  left: 50%;
  margin-left: -8px;
  margin-top: -8px;
  width: 16px;
  height: 16px;
  border: 1px solid #333;
  border-radius: 4px;
  transition: all 0.65s cubic-bezier(0.19, 1, 0.22, 1);
}

/**
 * iPad and iPad Mini
 */
.device--ipad .device__header,
.device--ipad-mini .device__header {
  width: 0;
  margin-left: 0;
  border-radius: 0;
  background: transparent;
}

.device--ipad .device__header:before,
.device--ipad-mini .device__header:before {
  transform: scale(0);
}

.device--ipad .device__header:after,
.device--ipad-mini .device__header:after {
  transform: translate(0, 12px);
}

.device--ipad .device__content {
  width: 614.4px;
  height: 819.2px;
  margin: 64px;
}

.device--ipad-mini .device__content {
  width: 614.4px;
  height: 819.2px;
  margin: 64px 20px;
}

/**
 * Browser
 */
.device--browser {
  border-radius: 6px;
  border-bottom-right-radius: 3px;
  border-bottom-left-radius: 3px;
}

.device--browser .device__header,
.device--browser .device__header:after,
.device--browser .device__header:before {
  width: 11.2px;
  height: 11.2px;
  left: 8px;
  top: 0px;
  transform: translate(0px, 0px) scale(1);
  margin-left: 0px;
  border-radius: 6px;
  background: transparent;
  border: 1px solid #333;
}

.device--browser .device__header {
  top: 10px;
}

.device--browser .device__header:before {
  left: 14px;
  top: -1px;
}

.device--browser .device__header:after {
  left: 30px;
  top: -1px;
}

.device--browser .device__content {
  width: 1024px;
  height: 640px;
  border-right-width: 0px;
  border-left-width: 0px;
  border-bottom-width: 0px;
  border-radius: 0px;
  border-bottom-right-radius: 3px;
  border-bottom-left-radius: 3px;
  margin: 32px 0px 0px 0px;
}

.device--browser .device__footer {
  transform: scale(0);
}

/**
 * Container to align the device in the center/middle
 * of the screen. I could use translate() for it, but
 * depending on the size of the window, the lines would
 * look blurred.
 */
.container {
	overflow: scroll;
  width: 100%;
  height: 100%;
  min-height: 100%;
  text-align: center;
  background: #aaec57;
  transition: background 0.65s cubic-bezier(0.19, 1, 0.22, 1);
}
.container:before {
  content: "";
  display: inline-block;
  height: 100%;
  vertical-align: middle;
}
.container > div {
  position: relative;
  display: inline-block;
  vertical-align: middle;
}

.container--ipad-mini {
  background: #67c4ff;
}

.container--ipad {
  background: #feec5d;
}

.container--browser {
  background: #f88482;
}

.nav {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 10;
  text-align: left;
  list-style: none;
  padding: 0;
  margin: 10px 0 0 10px;
}
.nav li {

font-size:30px;
  display: inline-block;
  margin-right: 10px;
  color: rgba(0, 0, 0, 0.4);
}
.nav .credits {
  display: block;
  font-size: 12px;
  margin-top: 5px;
}
.nav .credits a {
  border-bottom-width: 1px;
}
.nav a {
  color: rgba(0, 0, 0, 0.5);
  font-weight: bold;
  text-decoration: none;
  border-bottom: 2px solid transparent;
  transition: all 0.15s ease-out;
}
.nav a:hover {
  border-bottom-color: rgba(0, 0, 0, 0.5);
}


img{
	width: 100%;

}



.lds-color div{


border: 2px solid #4a154bd9 !important;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-ring {
	top: 50%;
	left: 50%;
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}


.href-back{

font-size: 2vh;
    padding: 3vh;
    float: right;
    color: white;
    width: 100%;
    background: black;
font-weight:600;
}

</style>


<body>


<div class="container" style='min-height:92vh;height:92vh;'>
  <div class="device">
    <div class="device__header"></div>
    <div class="device__content">
      
      
<img id="pre-temp-img-devi" src="http://ec2-3-21-105-231.us-east-2.compute.amazonaws.com/scr-api/?url=https://heptera.me/dash/main/template/crt-template/crtedtemp/<?php echo $temp_id;?>.html&width=480">
<div id="ld-of-pre-img" class='lds-ring lds-color '  style='display:none'><div></div><div></div><div></div><div></div></div>
    </div>
    <div class="device__footer"></div>
  </div>
</div>


<ul class="nav">


  <li><a href="#" data-device="" class="fad fa-mobile"></a></li>
  
  <li><a href="#" data-device="ipad" class="fad fa-tablet-alt"></a></li>
  <li><a href="#" data-device="browser" class="fad fa-desktop"></a></li>
  
</ul>

<a href="../../edit?editor_id=<?php echo $temp_id;?>" class="href-back" style="font-size:15px;"><i class="fad fa-long-arrow-left" style="padding-right:10px;"></i>Back To Editor</a>


</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">

temp_id=encodeURI('<?php echo $temp_id;?>');

function setDevice(device,temp_id) {




    deviceNs = device ? "device--" + device : "";
    containerNs = device ? "container--" + device : "";
    $(".device").removeClass().addClass("device " + deviceNs);
    $(".container").removeClass().addClass("container " + containerNs);

http://ec2-3-21-105-231.us-east-2.compute.amazonaws.com/scr-api/?url=https://heptera.me/dash/main/template/crt-template/crtedtemp/"+temp_id+"&width=1080
   

if(device=="ipad"){

$("#pre-temp-img-devi").attr("src","https://scr.sycista.com/scr-api/?url=https://template.sycista.com/template/crt-template/crtedtemp/"+temp_id+"&width=800");


}else if(device=="browser"){

$("#pre-temp-img-devi").attr("src","https://scr.sycista.com/scr-api/?url=https://template.sycista.com/template/crt-template/crtedtemp/"+temp_id+"&width=1080");

}else if(device==""){

$("#pre-temp-img-devi").attr("src","https://scr.sycista.com/scr-api/?url=https://template.sycista.com/template/crt-template/crtedtemp/"+temp_id+"&width=480");


}



$('#pre-temp-img-devi').on('load', function(){
    
        
$("#pre-temp-img-devi").css("display","block");
 $("#ld-of-pre-img").css("display","none");

     });



  };


$(function() {
  
  
  
  $(".nav").on("click", "a", function(e) {
    e.preventDefault();
    $("#pre-temp-img-devi").css("display","none");
    $("#ld-of-pre-img").css("display","block");
    setDevice($(e.target).data("device"),temp_id+".html");
  });
  
  $(window).on("keyup", function(e) {
 $("#pre-temp-img-devi").css("display","none");
 $("#ld-of-pre-img").css("display","block");
  	

    switch(e.keyCode) {
      case 49 :
        setDevice("",temp_id+".html");
        break;
      
      case 51 :
        setDevice("ipad",temp_id+".html");

        break;
      case 52 :
        setDevice("browser",temp_id+".html");

        
        break;
    }
  });





  
});

$(document).ready(function(){

setDevice("",temp_id+".html");


});



</script>

</html>




