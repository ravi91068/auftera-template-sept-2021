<?php



function create_db($conn,$db_name){




$sql = "CREATE DATABASE ".$db_name;
if ($conn->query($sql) === TRUE) {

echo "create db ".$db_name;

}




}



function create_tbl_in_db($conn,$sql){



if($conn->query($sql)==TRUE){

echo "create Table ";

}




}

$servername = "database-1.c2kbgonwhnk5.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";





$account_conn = mysqli_connect($servername, $username, $password);




#create_db($account_conn,"template");






$temp_conn = mysqli_connect($servername, $username, $password,'template');


$sql_query="CREATE TABLE `temp_details` (
 `tempname` varchar(255) NOT NULL,
 `id` int(255) NOT NULL,
 `date` date NOT NULL,
 PRIMARY KEY (`tempname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";


create_tbl_in_db($temp_conn,$sql_query);







?>