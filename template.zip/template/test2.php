<?php
$filecreateflag=file_put_contents("./edit-con-tem/index.html", $_POST["name"]);
echo $filecreateflag;





?>