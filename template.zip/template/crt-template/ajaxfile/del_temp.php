<?php

session_start();
require("../../confige/templateconfige.php");
 $id=$_SESSION["id"];

$temp_name=$_POST['temp_old_name'];

$rename_stat=unlink("../crtedtemp/".$temp_name.".html");


$del_temp_qr="DELETE FROM temp_details WHERE tempname='$temp_name'";
if( $rename_stat=="TRUE"){

if($template->query($del_temp_qr)==true){

echo 1;

}else{
  echo "Something Went Wrong";
}

}else{

  echo "Something Went Wrong";
}

?>
