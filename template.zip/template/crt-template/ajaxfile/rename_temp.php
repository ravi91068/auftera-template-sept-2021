
<?php


session_start();
require("../../confige/templateconfige.php");
 $id=$_SESSION["id"];

$temp_old_name=$_POST['temp_old_name'];
$temp_new_name=$_POST['temp_new_name'];
$temp_new_en_name=base64_encode($temp_new_name);
$temp_new_name=$id."^".$temp_new_en_name;

$update_temp_name = "UPDATE temp_details SET tempname='$temp_new_name' WHERE tempname='$temp_old_name'";

if($template->query($update_temp_name)==true){

	$rename_stat=rename('../crtedtemp/'.$temp_old_name.'.html','../crtedtemp/'.$temp_new_name.'.html');
if($rename_stat=="TRUE"){

echo 1;

}else{


echo "Something Went Wrong";

}


}else{



echo "Please Enter Unique Name";

}

?>
 
