<?php

session_start();
require("../../confige/templateconfige.php");
 $id=$_SESSION["id"];
$flg_crt=$_POST['temp_crt_flg'];


$flg_suc_temp=0;
$date_crt=date("Y-m-d");


if($flg_crt==1){

$temp_name_get= base64_encode($_POST['temp_name_get']);

$path_of_base=$_POST['path'];


$temp_name_def=$id."^".$temp_name_get;


}else{


$retrive_temp_name=explode('^', $_POST['temp_name_get']);
$deco_name=base64_decode($retrive_temp_name[1]);
$temp_emb_name=base64_encode($deco_name."-copy");
 $temp_name_def=$retrive_temp_name[0]."^".$temp_emb_name;

}

$sql = "INSERT INTO temp_details (id, tempname, date) VALUES ('$id', '$temp_name_def', '$date_crt')";



if($template->query($sql)==true){

$flg_suc_temp=1;

}







$temp_type=$_POST['type_temp'];


if($flg_suc_temp==1){


if($flg_crt==1){

if(copy($path_of_base.$temp_type.".html", "../crtedtemp/".$temp_name_def.".html")=='TRUE'){
        $flg_suc_temp=1;

}else{

	$flg_suc_temp=0;
}

}else{



if(copy("../crtedtemp/".$temp_type.".html", "../crtedtemp/".$temp_name_def.".html")=='TRUE'){

        $flg_suc_temp=1;
        
}else{


	$flg_suc_temp=0;
}


}








}else{


$flg_suc_temp=0;

}


echo $flg_suc_temp;

?>

