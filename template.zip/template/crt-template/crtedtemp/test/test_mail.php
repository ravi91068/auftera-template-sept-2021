<?php




$myfile = fopen("../4^UmF2aTY3NzY=.html", "r") or die("Unable to open file!");
$email_temp= fread($myfile,filesize("../4^UmF2aTY3NzY=.html"));
fclose($myfile);

echo $email_temp;

$to = "ravigorasiya65@gmail.com";
$subject = "My subject";
$txt = $email_temp;
$headers = "From: webmaster@example.com" . "\r\n" .
"CC: somebodyelse@example.com";

$maild= mail($to,$subject,$txt,$headers);

echo $maild;
?>



